# Jarvis backend — deploy in ~5 minutes

This is a Cloudflare Worker. It's free (generous free tier), needs no
server to maintain, and keeps your Anthropic API key secret — the key
never reaches the browser.

## 1. Get an API key
Go to https://console.anthropic.com/settings/keys and create a key.
Keep it somewhere safe; you'll paste it once in step 4 and never again.

## 2. Install Wrangler (Cloudflare's CLI)
You need Node.js installed, then:

    npm install -g wrangler
    wrangler login

This opens a browser tab to log into (or create) a free Cloudflare account.

## 3. Create the Worker project
In a new folder:

    wrangler init jarvis-backend
    # When prompted:
    #  - "Do you want to use TypeScript?" → No
    #  - "Do you want to deploy?" → No (not yet)

Replace the generated `src/index.js` (or `worker.js`, depending on the
template) with the `worker.js` file provided alongside this README.

## 4. Add your API key as a secret
    wrangler secret put ANTHROPIC_API_KEY
    # paste your key when prompted — it's stored encrypted by Cloudflare,
    # not in your code, not in git

## 5. Deploy
    wrangler deploy

Wrangler prints a URL like:

    https://jarvis-backend.yourname.workers.dev

That's your API_ENDPOINT.

## 6. Wire it into the app
Open `index.html`, find this line near the top of the `<script>` block:

    const API_ENDPOINT = "https://YOUR-WORKER-NAME.YOUR-SUBDOMAIN.workers.dev";

Replace it with the URL Wrangler gave you, save, and re-deploy the app
(re-drop the folder on Netlify, or push to GitHub Pages, etc.).

## 7. Lock down access (recommended)
By default `worker.js` sets `ALLOWED_ORIGIN = "*"`, so anyone could call
your Worker from any site and spend your API credits. Once your Jarvis
app has a permanent URL, open `worker.js` and change:

    const ALLOWED_ORIGIN = "*";

to:

    const ALLOWED_ORIGIN = "https://your-jarvis-app-url.netlify.app";

Then redeploy the Worker with `wrangler deploy` again.

## Costs
Cloudflare Workers: free tier covers 100,000 requests/day — plenty for
personal use. Anthropic API usage is billed separately by Anthropic
based on tokens used; check current pricing at
https://www.anthropic.com/pricing before heavy use.
